package Observation;

public interface INotificationObserver {

	void OnServerDown();
	

}
